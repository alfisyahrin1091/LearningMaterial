# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 15:03:47 2021

@author: gary
"""

import pandas as pd
from sklearn.pipeline import make_pipeline, Pipeline
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import joblib
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer

df = pd.read_csv('bank.csv', delimiter=',')

df_X = df.drop(['deposit'],axis=1)
df_y = df[['deposit']]

le = LabelEncoder()
df_y = le.fit_transform(df_y['deposit'])

nums = df_X.select_dtypes(include=['int64', 'float64']).columns
cats = df_X.select_dtypes(include=['object', 'bool']).columns

X_train, X_test, y_train, y_test = train_test_split(
    df_X, df_y, test_size=0.3, random_state=42)

numerical_transformer = SimpleImputer(strategy='median')
categorical_transformer = Pipeline(steps=[
('imputer', SimpleImputer(strategy='most_frequent')),
('imput', OneHotEncoder())
])

preprocessor = ColumnTransformer(
transformers=[
('num', numerical_transformer, nums),
('cat', categorical_transformer, cats)
])

pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('scaling', StandardScaler()), 
                           ('feature_selection', SelectFromModel(ExtraTreesClassifier(random_state=2), prefit=False)),
                           ('classifier', DecisionTreeClassifier(random_state=42, max_depth=10))])

pipeline = pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)

pipeline = pipeline.fit(X_train, y_train)
filename = 'trained_model.pkl'
joblib.dump(pipeline, filename)